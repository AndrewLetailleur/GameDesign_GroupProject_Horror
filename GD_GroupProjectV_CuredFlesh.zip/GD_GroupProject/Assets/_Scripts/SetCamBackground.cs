﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SetCamBackground : MonoBehaviour {

	new Camera camera;

	public Color FloorG = new Color(0.0F, 0.0F, 0.2F, 1F); //for background
	public Color Floor1 = new Color(0.0F, 0.0F, 0.1F, 1F); //for background
	public Color CourtY = new Color(0.0F, 0.2F, 0.0F, 1F); //for background

	void Start() {
		camera = GetComponent<Camera> ();
	}


	// Update is called once per frame
	void Update () {

		Scene scene = SceneManager.GetActiveScene();

		switch (scene.name) {
		case "_Ground_Floor": 
			camera.backgroundColor = FloorG;
			break;
		case "_First_Floor":
			camera.backgroundColor = Floor1;
			break;
		case "_Courtyard":
			camera.backgroundColor = CourtY;
			break;
		default:
			break;
		}




	}
}
