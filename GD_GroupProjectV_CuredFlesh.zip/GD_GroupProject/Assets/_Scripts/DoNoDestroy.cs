﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DoNoDestroy : MonoBehaviour {

	// Use this for initialization
	void Awake () {
		DontDestroyOnLoad(transform.gameObject);
	}


	void Update () {

		Scene scene = SceneManager.GetActiveScene();

		switch (scene.name) {
		case "_Ground_Floor": 
			break;
		case "_First_Floor":
			break;
		case "_Courtyard":
			break;
		default:
			ender();
			break;
		}
	}

	void ender() {
		Destroy (this.gameObject);
	}

	//call if game is over, say?
	void TimeOut () {

		Destroy (this.gameObject); //may also be 'this', but worth a shot.
		SceneManager.LoadScene("TimeOut"); //trig condition wise
	}

	void GameOver () {

		Destroy (this.gameObject); //may also be 'this', but worth a shot.
		SceneManager.LoadScene("GameOver"); //trig condition wise
	}

	void Victory () {

		Destroy (this.gameObject); //may also be 'this', but worth a shot.
		SceneManager.LoadScene("Victory"); //trig condition wise
	}

}
