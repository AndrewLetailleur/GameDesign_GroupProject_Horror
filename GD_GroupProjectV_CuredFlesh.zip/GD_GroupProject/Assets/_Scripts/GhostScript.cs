﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostScript : MonoBehaviour {

	public float Xp; //not to be confused with 'EXP', it's 'X points', push wise.
	public float Yp; // 'y' points, push wise.
	public int dmg = 7;
	Vector2 movement, velocity, direction;

	public float spd_m = 1.5F;

	private float str_p = 2.00F;
//	private float dia_p = 0.60F;
	private float nilla = 0.00F;

	public float lmt_rad = 0.3F;

	public float ticky = 1F;
	public float m_tck = 1F;
	public float tick_r = 1F;

	public GameObject spawner, player;
	public EnemySpawner spawnRef;
	public PlayerHealth playHP;

	Rigidbody2D rb2D;

	// Use this for initialization
	void Start () {
		rb2D = GetComponent<Rigidbody2D> ();
		spawner = GameObject.FindGameObjectWithTag ("Respawn");
		player = GameObject.FindGameObjectWithTag ("Player");
		playHP = player.GetComponent<PlayerHealth> ();
		spawnRef = spawner.GetComponent<EnemySpawner> ();
	}

	// Update is called once per frame
	void Update () {

		movement = new Vector2 (Xp, Yp);
		rb2D.velocity = movement;

			//update tick.
		if (ticky <= 0) {
			TracePath ();
			ticky = m_tck;
		} else 
			ticky = ticky - Time.deltaTime * tick_r;
		//end tick

	}

	void TracePath () {

		//begin basic trace path

		//x variables
		if (transform.position.x > (player.transform.position.x + lmt_rad) )
			Xp = (-str_p * spd_m);
		else if (transform.position.x < (player.transform.position.x - lmt_rad) )
			Xp = (str_p * spd_m);
		else
			Xp = nilla;
		//end if

		//y variables
		if (transform.position.y > (player.transform.position.y + lmt_rad) )
			Yp = (-str_p * spd_m);
		else if (transform.position.y < (player.transform.position.y - lmt_rad) )
			Yp = (str_p * spd_m);
		else
			Xp = nilla;
		//end if


		if ( Xp == 0 && Yp == 0) {
			Xp = Random.Range (-1.5F, 1.5F);
			Yp = Random.Range (-1.5F, 1.5F);
		}


		//guessed variables for later

		/*
		Xp =   str_p;
		Yp =   nilla;

		Xp =  -str_p;
		Yp =   nilla;

		Xp =   nilla;
		Yp =   str_p;

		Xp =   nilla;
		Yp =  -str_p;

		//diagonal

		Xp =  dia_p;
		Yp =  dia_p;

		Xp = -dia_p;
		Yp =  dia_p;

		Xp = -dia_p;
		Yp = -dia_p;

		Xp =  dia_p;
		Yp = -dia_p;



		*/

	}

	void OnTriggerEnter2D (Collider2D other) {
		if (other.CompareTag ("Player") ) {
			playHP.TakeDamage(dmg); //should be easier to edit, checker wise
			Die ();
		}

	}


	void Die () {
		spawnRef.curGhost--;
		Destroy (this.gameObject);
	}
}
