﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class VictoryFlag : MonoBehaviour {

	// Use this for initialization
	void Start () {/*Not Needed*/}

	// Update is called once per frame
	void Update () {/*Not Needed*/}

	//collision for physical objects ONLY.
	//collision for collision, and collider for trigger. ion ion, er er.
		//ALL 2D Collider tags for 2D colliders, NO 2D tags for 3D Colliders
	void OnTriggerEnter2D (Collider2D other) {
		if (other.CompareTag ("Player") )
			SceneManager.LoadScene ("Victory");	
	} // void OnTriggerExit2D (Collider2D other) {/*Not Needed*/}
}