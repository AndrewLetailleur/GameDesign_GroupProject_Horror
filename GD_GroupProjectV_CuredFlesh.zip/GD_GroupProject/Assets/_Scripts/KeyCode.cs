﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyCode : MonoBehaviour {

	public GameObject statts;
	public StatPreserveLoadup playRef;

	// Use this for initialization
	void Start () {
		statts = GameObject.FindWithTag ("Stats");
		playRef = statts.GetComponent<StatPreserveLoadup>();
	}
	
	// Update is called once per frame
	void Update () {
		if (playRef.keys)
			Destroy (this.gameObject);
	}
}
