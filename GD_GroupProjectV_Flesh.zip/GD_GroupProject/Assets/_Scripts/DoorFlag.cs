﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DoorFlag : MonoBehaviour {


	//FUTURE REF = "Door Code" should have a seperate check,
		//to see if a 'Key' check from player is needed.

	//public GameObject player; //< NOT NEEDED, to move scene to 'End Screen'.

	public bool Exit_Check;//if it's intended AS an exit, mainly.
	public string tGt;

	//note to door, best to check if player HAS key from player health itself, get component, instead of pass component wise.
	public bool R_hasKey;//from playKey, if key is at hand.
	public GameObject Player;

	// Use this for initialization
	void Start () {
		Player = GameObject.FindGameObjectWithTag ("Player");
		Scene scene = SceneManager.GetActiveScene();



		if (Exit_Check) {
			tGt = "Exit";
		} else {
			switch (scene.name) {
			case "_Ground_Floor": 
				tGt = "G_Check";
				break;
			case "_Ground_Floor_Re": 
				tGt = "G_Check";
				break;
			case "_First_Floor":
				tGt = "F_Check";
				break;
			case "_Courtyard":
				tGt = "Victory";
				break;
			default:
				break;
			}
		}
	}


	// Update is called once per frame
	void Update () {

		if (Player.GetComponent<PlayerHealth> ().hasKey == true)
			R_hasKey = true;
		else
			R_hasKey = false;
		//insert if key's true, checker's true checker.
	}



	//collision for physical objects ONLY.
	//collision for collision, and collider for trigger. ion ion, er er.
		//ALL 2D Collider tags for 2D colliders, NO 2D tags for 3D Colliders
	void OnTriggerEnter2D (Collider2D other) {

		if (other.CompareTag ("Player")) {
			switch (tGt) {
				case "G_Check":
				SceneManager.LoadScene ("_First_Floor");
					break;
				case "F_Check":
				SceneManager.LoadScene ("_Ground_Floor_Re");
					break;
				case "Exit":
					if (R_hasKey == true){
						SceneManager.LoadScene ("_Courtyard");
						break;
					}
					else {
						//insert HUD alert, saying "NEED KEY!" sound effect.
						SceneManager.LoadScene ("_Ground_Floor");
						break;//end if
					}
				case "Victory":
					SceneManager.LoadScene ("Victory");
					break;
				default:
					break;
				//end case
			}
		} 
	}

	void OnTriggerExit2D (Collider2D other) {/*Not Needed*/}

}
