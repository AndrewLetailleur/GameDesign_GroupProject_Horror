﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class PlayerCode : MonoBehaviour {

	/**
	 * REFERENCES
	 * ==========
	 * http://answers.unity3d.com/questions/1305167/character-movement-component.html
	 * http://answers.unity3d.com/questions/630670/rotate-2d-sprite-towards-moving-direction.html
	 *===========
	 *///end REF



	Animator anime; //for animation, named after Japanese term
	Rigidbody2D rb2D;

	public float horz_Move, vert_Move, sprint, mov_Speed;
	public bool canRun, isRunning;

	public float norSpeed = 0.2f; // walking
	public float maxSpeed = 0.5f; // sprinting7
	public float rotValue = 0f; // Rotation value

	public float mStamina = 5f; // ideally in seconds
	public float Stamina = 5f;

	public Vector2 velocity, movement; //for velocity reference


	// Use this for initialization
	void Start () {
		horz_Move = vert_Move = 0; //init zero movement
		canRun = true;

//		if(GetComponent<Rigidbody2D>()) {
			rb2D = GetComponent<Rigidbody2D> ();
//		} else
//		Debug.LogError("No rigidbody detected");
		//end if

		//EX: anim = GetComponent<Animator>(); // to be verified //anime component
	}

	void Update() {
		if (Stamina <= 0) //when Stamina is BELOW zero
			canRun = false;
		//end if
		if (Stamina < mStamina) {//if below max stamina, recover stamina
			if (canRun)
				Stamina += Time.deltaTime / 2; //normal rate
			else
				Stamina += Time.deltaTime / 3; //exhausted rate
		} else if (Stamina > mStamina) //when Stamina is ABOVE max
			Stamina = mStamina;
		else if (!canRun) //when mStamina is EXACTLY at max.
			canRun = true;
		//end if
	}

	void FixedUpdate()
	{
		GetInput();
		//Turn();
	}
		
	void GetInput()
	{
		horz_Move = Input.GetAxis ("Horizontal"); // deals with X axis movement
		vert_Move = Input.GetAxis ("Vertical"); // deals with Y axis movement
		sprint = Input.GetAxis ("Jump");
		Move ();
	}
		
	void Move() {

		/**
		 * Moves the player towards the direction of player input
		 * Pretty simple, and elegant. So long as a single condition is met.
		 * 
		 * ADDED Code - can now totally sprint. But IF sprinting, will consume Stamina.
		 * If player is not running, will slowly recover stamina.
		 * And if out of stamina, the player can't run again until stamina has recovered at a slower rate.
		 */
		if (horz_Move != 0 || vert_Move != 0 ) {
			if (sprint != 0 && canRun) {
				movement = new Vector2 (horz_Move * maxSpeed, vert_Move * maxSpeed);
				Stamina -= Time.deltaTime;
			} else {
				movement = new Vector2 (horz_Move * norSpeed, vert_Move * norSpeed);
			}
			rb2D.velocity = movement;
			velocity = rb2D.velocity;
		} else
			rb2D.velocity = Vector2.zero;
		//end if movement sequence


		/**
		 * Rotates the character to movement direction.
		 * As a bonus, smoothens out rotation to be a bit more 'natural'.
		 * =====
		 * Only quirk was 'x' was moving funny, so I fixed that.
		 */

		/* //Commented out, due to recent assets clashing with a sort of 'top down' view, thus no more rotationary.
		if (velocity != Vector2.zero) {
			rotValue = Mathf.Atan2 (-velocity.x, velocity.y) * Mathf.Rad2Deg;
			transform.rotation = Quaternion.AngleAxis(rotValue, Vector3.forward);
		}*/ //end if rotationary

		//I thank this reference for showing me a more elegant sollution

		/**
		 * I thank this reference for showing me a more elegant sollution,
		 * than "Unlimited If Statements, instead of case statements.
		 * Best part is, the power of Mathf is blessed here!
		 * ===
		 */ // 
	}

}