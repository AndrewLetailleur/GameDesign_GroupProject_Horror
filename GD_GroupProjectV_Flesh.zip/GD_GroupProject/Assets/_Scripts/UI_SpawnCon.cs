﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_SpawnCon : MonoBehaviour {

	public GameObject Statts; //switching to spawn statts, in hopes of passing on variables and such ONLY

	// Use this for initialization
	void Start () {

		GameObject[] statty = GameObject.FindGameObjectsWithTag ("Stats");

		if (statty.Length == 0) {//if there isn't at least ONE HUD in sight...
			Instantiate (Statts, new Vector3 (0, 0, 0), transform.rotation);
		}

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
