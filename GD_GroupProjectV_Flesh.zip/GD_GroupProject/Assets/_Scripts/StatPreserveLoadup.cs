﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StatPreserveLoadup : MonoBehaviour {

	public float RotateZ = 20f;
	public float PlayHP = 100f;
	public int MaxHP = 100;
	public bool keys = false;
	public float curseRate = 0f;

	// upon loading
	void Awake () {
		DontDestroyOnLoad(this);
	}

	// Use this for initialization
	void Start () {
		
	}
	
	void Update () {

		Scene scene = SceneManager.GetActiveScene();

		switch (scene.name) {
		case "GameOver": 
			ender();
			break;
		case "TimeOut":
			ender();
			break;
		case "Victory":
			ender();
			break;
		case "MainMenu":
			ender();
			break;
		case "HelpMenu":
			ender();
			break;
		default:
			break;
		}
	}

	void ender() {
		Destroy (this.gameObject);
	}
}
