﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;//required for UI components
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour {

	public GameObject statts;
	public StatPreserveLoadup playRef;

	public int max_HP = 100;
	public float curr_HP;

	public Slider HP_Slider;
	public Image damageIMG;
	public AudioClip deathClip; //for a RIP dead end cry

	public float flashSpeed = 3f; // for sudden flashing
	public Color flashColor = new Color(1, 0, 0, 225); //for flashing, stick to US spelling here

	public bool hasKey;
	public EnemySpawner spawnRef;

//	Animator anim;
//	AudioSource playerAudio; //guessed variables
//	PlayerCode playerMovement;

//	Animator anim;		// there, JNC
//	AudioSource playerAudio; //audiowise, guess shot

	public bool isDead;
	public bool damaged; //determine damage, and if dead variable.

	// Use this for initialization
	void Start () {

		statts = GameObject.FindWithTag ("Stats");
		playRef = statts.GetComponent<StatPreserveLoadup>();

		curr_HP = playRef.PlayHP;
		max_HP = playRef.MaxHP;
		hasKey = playRef.keys; //altered to enable carrying of keys

			//set up health full at start
		HP_Slider.maxValue = max_HP; //in order to avoid float technical difficulties
		HP_Slider.value = curr_HP;
	}

	void OnTriggerEnter2D (Collider2D other) {
		if (other.CompareTag ("Key") ) {
			hasKey = true;
			playRef.keys = hasKey;
			Destroy (GameObject.FindWithTag("Key") );
		}
/*		if (other.CompareTag ("Enemy") ) {
			spawnRef.curGhost--;
			TakeDamage(3);
		}*/

	}

	void Update() {

		//excessive, but seems to get the job done, in a sense.
		statts = GameObject.FindWithTag ("Stats");
		playRef = statts.GetComponent<StatPreserveLoadup>();

		playRef.PlayHP = curr_HP;
		playRef.MaxHP = max_HP;


		if (Input.GetMouseButtonDown(0)) {
			TakeDamage (3);
		}

		//suffers from technical issues, test wise. Possible concern IF thinking of adding a 'flashlight' feature.
			//#### it; UNTIL a more viable sollution is found, just DODGE working on this further. As I've a limited amount of time, and zero amount of patience to deal with this ####.

		/*if (Input.GetKeyDown(UnityEngine.KeyCode.E)) {
		TakeDamage (3);
		}*/

	}

	// Update is called once per frame
	void FixedUpdate () {




		//https://www.youtube.com/watch?v=6Z7_ZbNUNw8

			//reference to fix HP Bar error

		//https://www.youtube.com/watch?v=UKs1qO8w7qc

			//another ref

		if (damaged) {
			damageIMG.color = flashColor;
			damaged = false;
		} else {
			damageIMG.color = Color.LerpUnclamped (damageIMG.color, Color.clear, flashSpeed * (Time.deltaTime / 2) );
		}

		//end damage component
	}

	public void TakeDamage (int amount)
	{
		damaged = true;

		curr_HP -= amount;
		HP_Slider.value = curr_HP;


		//playerAudio.Play ();

		if (curr_HP <= 0 && !isDead)
		{
			DeathTrig ();
		}
	}



	void DeathTrig ()
	{
		isDead = true;

		SceneManager.LoadScene("GameOver");

		//anim.SetTrigger ("Die");

		//playerAudio.clip = deathClip
		//playerAudio.Play ();

		//PlayerCode.enabled = false;// disable movement, no more moving.



	}


}
