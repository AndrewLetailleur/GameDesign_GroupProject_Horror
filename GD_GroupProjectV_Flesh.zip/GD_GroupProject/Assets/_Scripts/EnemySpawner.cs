﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour {

	//to get play REF on curse rate and such

	public GameObject statts;
	public StatPreserveLoadup playRef;

	//now for referred code and such

	public float TimerRot;
	public int curseRater; //lower rotation, higher = more spawn?

	/*BEGIN SPAWN VARIABLES?*/

		//set up ghost pop, TDL; also ensure ghost's update cur pop cap.
	public int maxGhost, curGhost;

	//beginning of test rotary data
	float rZero =   0F;
	float rL_Lo =  90F;
	float rD    = 180F;
	float rR    = 270F;
	float rU    = 360F;
	float rL_Hi = 450F;//the loop to zero, aspect
	//for edge trimming, et all
	float rVar  =  30F;

	//randomisers
	public int Rando, oRando; //RNG here, logic wise
	[SerializeField][Range(1,100)]
	public int minRNG = 33; //the min, rig it so that it's max - curse * X?

	//Last Timers
	public float callTimer = 3F;//minimum time
	public float maxTimer = 3F;//max time, deltaTime wise

	//base z value
	public float zVal = -1.5F; //should ideally spawn at middle, angle wise.

	/*END SPAWN VARIABLES?*/

	//position reference
	public Camera cam;
	public Vector3 camPos;
	//public Vector2 cViewP; //set up spawn positions

	public GameObject getPlayer;//grab ze player

	//not needed to look at, camera variables
	public float vertExtent, horzExtent, oXmax, oYmax, cX, cY;

	//spawn object general
	public GameObject ghost; //no beast reference here!

	// Use this for initialization
	void Start () {
		statts = GameObject.FindWithTag ("Stats");
		playRef = statts.GetComponent<StatPreserveLoadup>();
		getPlayer = GameObject.FindGameObjectWithTag ("Player");
		curseRater = 1;//some value to start with

		cam = Camera.main; // grab main camera, SHOULD be already there
		oYmax = 2f * cam.orthographicSize;//height wise, possibly refix to different scale?
		oXmax = oYmax * cam.aspect;//again, recheck to curr camera settings.

		vertExtent = (oYmax / 2f);
		horzExtent = (oXmax / 2f);

		cX = cam.transform.position.x;
		cY = cam.transform.position.y;

		curGhost = 0;//as there's no ghosts in stage, initially.

	}
	
	// Update is called once per frame
	void Update () {

		cX = cam.transform.position.x;
		cY = cam.transform.position.y;

			//since it won't be found initially.
		statts = GameObject.FindWithTag ("Stats");
		playRef = statts.GetComponent<StatPreserveLoadup>();

		curseCheck();//to tidy up update

		if (callTimer <= 0F) {
			SpawnEnemy (); //call the spawn enemy function
			callTimer = maxTimer; //reset timer
		} else 
			callTimer -= Time.deltaTime;//take time away, timer wise
		// end if
	}//end update


	void SpawnEnemy() {
		//roll the dice

		Rando = Random.Range (1, 100);//d100 logic wise
		//s_x = spawn_x (l/eft, r/ight, u/p, d/own)
		Vector2 s_l = new Vector2 ( (-horzExtent + cX), Random.Range ( (-vertExtent + cY), (vertExtent + cY) ) );
		Vector2 s_r = new Vector2 ( ( horzExtent + cX), Random.Range ( (-vertExtent + cY), (vertExtent + cY) ) );
		Vector2 s_u = new Vector2 (Random.Range ( (-horzExtent + cX), (horzExtent + cX) ), ( vertExtent + cY) );
		Vector2 s_d = new Vector2 (Random.Range ( (-horzExtent + cX), (horzExtent + cX) ), (-vertExtent + cY) );
		//end guessy spawners

		//if RNG is trigged, start to spawn if pop cap isn't reached

		if ((Rando > minRNG) & (curGhost < maxGhost)) 
			oRando = Random.Range (1, 5);//get random number between 1-4, due to funky code quirks with C#
		 else
			oRando = 0;
		//end if

		if (oRando > 0) {
			curGhost++; //increase pop cap for a new ghost.

			switch (oRando) {
				case 1: //righty
					Vector3 ghoPosR = new Vector3 (s_r.x, s_r.y, zVal);
					Instantiate(ghost, ghoPosR, Quaternion.Euler (0, 0, Random.Range ( (rZero + rVar), (rD - rVar) )));
					break;
				case 2:
					Vector3 ghoPosU = new Vector3 (s_u.x, s_u.y, zVal);
					Instantiate(ghost, ghoPosU, Quaternion.Euler (0, 0, Random.Range ( (rL_Lo + rVar), (rR - rVar) )));
					break;
				case 3:
					Vector3 ghoPosL = new Vector3 (s_l.x, s_l.y, zVal);
					Instantiate(ghost, ghoPosL, Quaternion.Euler (0, 0, Random.Range ( (rD + rVar), (rU - rVar) )));
					break;
				case 4:
					Vector3 ghoPosD = new Vector3 (s_d.x, s_d.y, zVal);
					Instantiate(ghost, ghoPosD, Quaternion.Euler (0, 0, Random.Range ( (rR + rVar), (rL_Hi - rVar) )));
					break;
				default:
					curGhost--;
					break;//break out error code here, deduct automaticly if no spawning is trig'd.
			}
		}
	}//end spawn enemy

	void curseCheck () {
		//update timerRot
		TimerRot = playRef.RotateZ;

		//enter update curseRater valve.
		switch (curseRater) {
		case 1:
			maxGhost = 0;
			if (TimerRot > 40)
				curseRater = 2;
			break;
		case 2:
			maxGhost = 2;
			if (TimerRot < 320)
				curseRater = 3;
			break;
		case 3:
			maxGhost = 3;
			if (TimerRot < 280)
				curseRater = 4;
			break;
		case 4:
			maxGhost = 5;
			if (TimerRot < 240)
				curseRater = 5;
			break;
		case 5:
			maxGhost = 7;
			if (TimerRot < 200)
				curseRater = 6;
			break;
		case 6://stop here, break
			maxGhost = 8;
			break;
		default://loop back to 1 otherwise
			curseRater = 1;
			break;
		}//end switch case statement
	}//end curse check
}