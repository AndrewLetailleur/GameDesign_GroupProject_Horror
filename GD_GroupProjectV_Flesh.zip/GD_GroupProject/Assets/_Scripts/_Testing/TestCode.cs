﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TestCode : MonoBehaviour {

	// Use this for initialization
	void Start () { /*INSERT empty space*/ }


	// Update is called once per frame
	void Update () {

		/* one last test
		if (Input.GetKeyDown (KeyCode.Space)) {
			SceneManager.LoadScene("Victory");
		} it works!
		*/

		/*if (Input.GetKeyDown (KeyCode.Mouse0)) {
			SceneManager.LoadScene("GameOver");
		} else if (Input.GetKeyDown (KeyCode.Mouse1)) {
			SceneManager.LoadScene("TimeOut");
		}*/
	}
}
