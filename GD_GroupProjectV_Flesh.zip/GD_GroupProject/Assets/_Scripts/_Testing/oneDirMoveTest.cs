﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class oneDirMoveTest : MonoBehaviour {

	public float Xp; //not to be confused with 'EXP', it's 'X points', push wise.
	public float Yp; // 'y' points, push wise.
	Vector2 movement, velocity;

	Rigidbody2D rb2D;

	// Use this for initialization
	void Start () {
		rb2D = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () {

			movement = new Vector2 (Xp, Yp);
			rb2D.velocity = movement;

	}
}
